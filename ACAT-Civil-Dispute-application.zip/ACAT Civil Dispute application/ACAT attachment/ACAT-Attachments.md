---
numbersections: true
title: Attachments to Civil Dispute Application
...


1. Detailed History of the Dispute

1. List of Damaged Items

2. Proofs of Purchase
    * Bike repair quote & receipt
    * Helmet transaction & item description 
    * Rear light receipt
    * Front light receipt
    * Trousers receipt

3. Photos
    * Damaged Bike lock (2 photos)
    * Damaged Rear Light (2 photos)
    * Damaged Trousers (2 photos)
    * Damaged Shoes (3 photos)

\newpage
# Detailed History of the Dispute

On 24th March 2023 at approximately 9.55am I was cycling on my push bike
on Northbourne Avenue in northerly direction towards the crossing with
Antill St where I wanted to turn right, when a car hit my bike from
behind.

I got catapulted approx. 5 meters forward and then fell to the left of
my bike. The car stopped behind me. The driver stepped out and talked to
me. A pedestrian was at the scene as well. The driver told the
pedestrian and me that he had hit me.

I remember that I had checked before the accident for cars behind me and
I had noticed that all cars were quite far (approx. 100 m) behind me.

After the crash I moved away from the street and felt quite some pain,
so I crouched down to rest. After approx. a minute I felt good enough to
slowly get up. I asked the driver and the pedestrian for their details
and took on advice of the pedestrian a photo of the car. The driver was
Mr Gath Berry. The pedestrian who had witnessed the accident was James
Reay.

I was not able to continue riding and additionally I realised something
was not right with my bike, so I just wheeled my bike back home where I
lay down to rest.

Later that day I went to my GP because the pain in the groin area
increased. I sustained a tear to the right adductor muscle and, as was
later revealed, whiplash in my neck. I am still in treatment for the
injuries. - Mr Gath Berry\'s compulsory third-party insurance (NRMA)
accepted to cover the medical costs from the accident.

I assessed my belongings and I noticed that the bike needed significant repair
and bike helmet, lights and other items needed replacement (see attached list
of items as well receipts and photos as evidence). The cost of the damage comes
to 1672.65 AUD.

I contacted the pedestrian James Reay and asked him whether he is
willing to write a statement about the accident. His report from 3rd May
is attached. James Reay clearly states in the report that Mr Berry
admitted at the scene that he had hit me.

On 27 March I had filed an incident report with the police (incident
number 7388455) and, because the phone number I had written down from Mr
Gath Berry had been wrong, police investigated and Constable Jess Forge
gave me the correct details of the driver from the photo of the vehicle
I had taken.

To get reimbursed for the damaged property I contacted Mr Berry
initially via phone, but he was completely unwilling to reimburse me for
the damage he had caused with the accident. On 22nd May 2023 I then sent
him a Letter of Demand requesting reimbursement within 14 days. Until
today he neither paid the damage nor replied to the letter in any way.

Therefore, I now apply to ACAT to recover the damages.

\newpage
# List of Damaged Items

\bgroup
\setstretch{0.9}
\renewcommand*{\arraystretch}{1.5}

  -----------------------------------------------------------------------
  **Item**    **Details (and attached evidence)**                **Cost**
  ----------- ------------------------------------------- ---------------
  Bike repair Repair at Monkey Wrench Cycles.\                   \$635.00
              (Repair quote & receipt)                    

  UVEX helmet To be replaced after a crash.                      \$134.70
              From Germany for \euro\thinspace 89.95.\
              (Transaction details & item description)    

  ABUS Bike   Broken. Not opening anymore.\                         \$150
  lock        (2 Photos)                                  

  Cycliq rear Broken. Does not work anymore.\                    \$194.00
  light       (Receipt + 2 Photos)                        

  Cycliq      Lost at accident scene.\                           \$429.00
  front light (Receipt)                                   

  Muji        Damaged with hole. Unusable.\                       \$59.95
  trousers    (Receipt + 2 Photos)                                     

  KEEN shoes  Damaged. Still usable. Value reduction from         \$70.00
              \$180.\                                     
              (3 Photos)                                  

  **Total**                                                 **\$1672.65**
  -----------------------------------------------------------------------

\egroup

\newpage
# Proofs of Purchase

### Bike repair quote & receipt

![](img/Monkey-Wrench-Leo-recumbent-quote.png){ width=60% } &nbsp;
![](img/Monkey-Wrench-receipt-000.png){ width=30% } &nbsp;

\newpage
### Helmet transaction & item description 

![](img/Helmet-transaction_No-card.jpg){ width=60% } &nbsp;

![](img/Helmet-description.png){ width=70% } &nbsp;

### Rear light receipt

![](img/Pushys-Fly6-Invoice.png){ width=55% } &nbsp;

### Front light receipt

![](img/Cycliq-Fly12-invoice-32560 2_No-details.jpg){ width=65% } &nbsp;

### Trousers receipt

![](img/Muji-Pants-Invoice.png){ width=30% } &nbsp;

\newpage
# Photos

### Damaged Bike lock (2 photos)

![](img/Northbourne-accident-damage_Lock_IMG_4950.jpeg){ height=47% } &nbsp;

![](img/Northbourne-accident-damage_Lock_IMG_4952.jpeg){ height=41% } &nbsp;


### Damaged Rear Light (2 photos)

![](img/Northbourne-accident-damage_Rear-light_IMG_4946.jpeg){ height=46% } &nbsp;

![](img/Northbourne-accident-damage_Rear-light_IMG_4947.jpeg){ height=46% } &nbsp;

### Damaged Trousers (2 photos)


![](img/Northbourne-accident-damage_trousers_IMG_4948.jpeg){ height=48% } &nbsp;

![](img/Northbourne-accident-damage_trousers_IMG_4949.jpeg){ height=42% } &nbsp;

### Damaged Shoes (3 photos)

![](img/Northbourne-accident-damage_Shoe_IMG_4953.jpeg){ height=46% } &nbsp;

![](img/Northbourne-accident-damage_Shoe_IMG_4954.jpeg){ width=45% } &nbsp;
![](img/Northbourne-accident-damage_Shoe_IMG_4955.jpeg){ width=45% } &nbsp;

<!--  LocalWords:  Gath YDG34Z  NRMA
 -->
