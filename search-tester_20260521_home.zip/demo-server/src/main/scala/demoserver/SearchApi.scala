package demoserver

import sttp.tapir.*
import sttp.tapir.json.circe.*
import sttp.tapir.generic.auto.*
import io.circe.generic.auto.*

import scala.concurrent.Future

/** A single document in the demo search index. */
case class SearchResult(id: Int, title: String, snippet: String)

/** The response returned by the search endpoint. */
case class SearchResponse(query: String, count: Int, results: List[SearchResult])

/** Endpoint definitions and logic for the demo search REST API. */
object SearchApi:

  /** A tiny in-memory document collection to search over. */
  private val documents = List(
    SearchResult(1, "Introduction to Pali",
      "Pali is the liturgical language of Theravada Buddhism."),
    SearchResult(2, "Pali grammar basics",
      "An overview of Pali noun declensions and verb conjugations."),
    SearchResult(3, "Reading the Dhammapada",
      "A guide to reading the Dhammapada in the original Pali.")
  )

  /** GET /search?q=... — describes inputs, outputs and errors. */
  val searchEndpoint: PublicEndpoint[String, String, SearchResponse, Any] =
    endpoint.get
      .in("search")
      .in(query[String]("q"))
      .out(jsonBody[SearchResponse])
      .errorOut(stringBody)
      .summary("Search the demo document collection")

  /** Server logic: case-insensitive substring match over title and snippet. */
  private def search(q: String): Future[Either[String, SearchResponse]] =
    if q.trim.isEmpty then
      Future.successful(Left("Query parameter 'q' must not be empty"))
    else
      val needle = q.toLowerCase
      val matches = documents.filter: doc =>
        doc.title.toLowerCase.contains(needle) ||
          doc.snippet.toLowerCase.contains(needle)
      Future.successful(Right(SearchResponse(q, matches.size, matches)))

  /** The endpoint bound to its server logic, ready to be served. */
  val searchServerEndpoint =
    searchEndpoint.serverLogic(search)
