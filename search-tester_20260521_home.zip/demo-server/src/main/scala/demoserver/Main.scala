package demoserver

import sttp.tapir.server.ServerEndpoint
import sttp.tapir.server.netty.NettyFutureServer
import sttp.tapir.swagger.bundle.SwaggerInterpreter

import scala.concurrent.{Await, Future}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.io.StdIn

/** Entry point: starts the Netty-backed Tapir server. */
object Main:

  private val port = 8080

  def main(args: Array[String]): Unit =
    // Swagger UI + OpenAPI spec generated from the endpoint definitions.
    val swaggerEndpoints: List[ServerEndpoint[Any, Future]] =
      SwaggerInterpreter()
        .fromEndpoints[Future](
          List(SearchApi.searchEndpoint),
          "Demo Search API",
          "1.0.0"
        )

    val binding =
      Await.result(
        NettyFutureServer()
          .port(port)
          .addEndpoints(swaggerEndpoints :+ SearchApi.searchServerEndpoint)
          .start(),
        Duration.Inf
      )

    println(s"Demo server running at http://localhost:$port")
    println(s"Try: curl 'http://localhost:$port/search?q=pali'")
    println(s"Swagger UI: http://localhost:$port/docs")
    println("Press ENTER to stop.")
    StdIn.readLine()

    Await.result(binding.stop(), Duration.Inf)
