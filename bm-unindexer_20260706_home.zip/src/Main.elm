module Main exposing (main)

import Browser
import Char
import Config exposing (solrCollection, solrInstance)
import Html exposing (Attribute, Html, button, div, h1, input, label, p, text)
import Html.Attributes exposing (autofocus, id, placeholder, style, title, value)
import Html.Events exposing (onClick, onInput)
import Http
import Json.Decode as Decode exposing (Decoder)
import Process
import Task
import Url.Builder



-- CONSTANTS
--
-- Domain vocabulary (see instruction 03):
--   * "store ID"  = the Solr `store` field value.
--   * "row"       = a single Solr document.
--   * "document"  = all rows (Solr documents) sharing the same store ID.


{-| The app title.
-}
appTitle : String
appTitle =
    "BM-unindexer"


{-| Canonical prefix of a full store ID.
-}
storeIdPrefix : String
storeIdPrefix =
    "fusion:/store/"


{-| Value pre-seeded into the Store ID field for convenient testing.
-}
seedStoreId : String
seedStoreId =
    storeIdPrefix ++ "11111111-1111-1111-1111-111111111111"


{-| Whether to insert the seed value on start-up.
-}
useSeed : Bool
useSeed =
    True



-- MAIN


main : Program () Model Msg
main =
    Browser.element
        { init = init
        , update = update
        , subscriptions = subscriptions
        , view = view
        }



-- MODEL


type alias Model =
    { storeId : String
    , feedback : Feedback

    -- When a delete is awaiting confirmation, holds what would be deleted.
    , confirm : Maybe Confirm

    -- Momentarily hides the feedback message to flicker it, so a repeated
    -- (identical) validation error is still noticeable.
    , flickerHidden : Bool
    }


{-| A pending delete, shown in the confirmation dialog.
-}
type alias Confirm =
    { storeId : String
    , count : Int
    }


{-| Message shown near the Store ID field.
-}
type Feedback
    = NoFeedback
    | Invalid String
    | Loading
    | Exists Int
    | Missing
    | Deleting
    | Deleted Int
    | Failed String


{-| Which button initiated a row check. Both check the rows; Delete does more.
-}
type Action
    = CheckOnly
    | DeleteDoc


init : () -> ( Model, Cmd Msg )
init _ =
    ( { storeId =
            if useSeed then
                seedStoreId

            else
                ""
      , feedback = NoFeedback
      , confirm = Nothing
      , flickerHidden = False
      }
    , Cmd.none
    )



-- UPDATE


type Msg
    = StoreIdChanged String
    | CheckClicked
    | DeleteClicked
    | DefaultClicked
    | GotCount Action String (Result Http.Error Int)
    | ConfirmDelete
    | CancelDelete
    | GotDelete Int (Result Http.Error ())
    | FlickerDone


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        StoreIdChanged newValue ->
            ( { model | storeId = newValue }, Cmd.none )

        CheckClicked ->
            startCheck CheckOnly model

        DeleteClicked ->
            startCheck DeleteDoc model

        DefaultClicked ->
            ( { model | storeId = seedStoreId, feedback = NoFeedback, confirm = Nothing, flickerHidden = False }, Cmd.none )

        FlickerDone ->
            ( { model | flickerHidden = False }, Cmd.none )

        GotCount action storeId result ->
            case result of
                Ok count ->
                    if count <= 0 then
                        ( { model | feedback = Missing }, Cmd.none )

                    else
                        case action of
                            CheckOnly ->
                                ( { model | feedback = Exists count }, Cmd.none )

                            DeleteDoc ->
                                -- Document exists: ask for confirmation before deleting.
                                -- Keep the "exists" message so Cancel leaves it in place.
                                ( { model | feedback = Exists count, confirm = Just { storeId = storeId, count = count } }
                                , Cmd.none
                                )

                Err err ->
                    ( { model | feedback = Failed (httpErrorToString err) }, Cmd.none )

        ConfirmDelete ->
            case model.confirm of
                Just c ->
                    ( { model | confirm = Nothing, feedback = Deleting }, deleteRows c.count c.storeId )

                Nothing ->
                    ( model, Cmd.none )

        CancelDelete ->
            -- Leave the "Document exists with n rows" feedback untouched.
            ( { model | confirm = Nothing }, Cmd.none )

        GotDelete count result ->
            case result of
                Ok () ->
                    ( { model | feedback = Deleted count }, Cmd.none )

                Err err ->
                    ( { model | feedback = Failed (httpErrorToString err) }, Cmd.none )


{-| Shared entry point for both buttons (DRY): validate the store ID, then kick
off the row check. This is the single place that decides what a "check" means.
-}
startCheck : Action -> Model -> ( Model, Cmd Msg )
startCheck action model =
    case parseStoreId model.storeId of
        Nothing ->
            -- Hide the message, then FlickerDone reveals it again shortly after,
            -- so a repeated identical error still visibly flickers.
            ( { model | feedback = Invalid invalidMessage, confirm = Nothing, flickerHidden = True }
            , Process.sleep 150 |> Task.perform (\_ -> FlickerDone)
            )

        Just normalized ->
            ( { model | feedback = Loading, confirm = Nothing, flickerHidden = False }, fetchRowCount action normalized )



-- STORE ID PARSING / VALIDATION


{-| Accept either a full store ID ("fusion:/store/<uuid>") or a bare "<uuid>",
returning the canonical full form. Returns Nothing for anything else.
-}
parseStoreId : String -> Maybe String
parseStoreId raw =
    let
        trimmed =
            String.trim raw

        uuid =
            if String.startsWith storeIdPrefix trimmed then
                String.dropLeft (String.length storeIdPrefix) trimmed

            else
                trimmed
    in
    if isValidUuid uuid then
        Just (storeIdPrefix ++ uuid)

    else
        Nothing


{-| True for the canonical 8-4-4-4-12 hex UUID form.
-}
isValidUuid : String -> Bool
isValidUuid s =
    case String.split "-" s of
        [ a, b, c, d, e ] ->
            List.all identity
                [ String.length a == 8
                , String.length b == 4
                , String.length c == 4
                , String.length d == 4
                , String.length e == 12
                , String.all Char.isHexDigit (a ++ b ++ c ++ d ++ e)
                ]

        _ ->
            False


invalidMessage : String
invalidMessage =
    "Invalid store ID. Use e.g. \"fusion:/store/f439375d-98d1-4940-bef2-11a727ed8376\" or just the UUID part."



-- SOLR


{-| Count the rows for a store ID. Both buttons funnel through here (DRY).
The `store` field is a Solr string field, so an exact phrase match is used.
-}
fetchRowCount : Action -> String -> Cmd Msg
fetchRowCount action storeId =
    Http.get
        { url = selectUrl storeId
        , expect = Http.expectJson (GotCount action storeId) numFoundDecoder
        }


{-| Direct request to the Solr instance. This is cross-origin, so Solr must
send CORS headers (see the `solr-cors` justfile recipe). The browser reaches
the host fine even though this machine's generic IPv4 routing to it is flaky.
-}
selectUrl : String -> String
selectUrl storeId =
    Url.Builder.crossOrigin solrInstance
        [ "solr", solrCollection, "select" ]
        [ Url.Builder.string "q" ("store:\"" ++ storeId ++ "\"")
        , Url.Builder.int "rows" 0
        , Url.Builder.string "wt" "json"
        ]


numFoundDecoder : Decoder Int
numFoundDecoder =
    Decode.at [ "response", "numFound" ] Decode.int


{-| Delete every row of the document identified by `storeId` (delete-by-query),
committing immediately. `count` is carried through only for the result message.
-}
deleteRows : Int -> String -> Cmd Msg
deleteRows count storeId =
    Http.post
        { url = updateUrl
        , body = Http.stringBody "text/xml" ("<delete><query>store:\"" ++ storeId ++ "\"</query></delete>")
        , expect = Http.expectWhatever (GotDelete count)
        }


updateUrl : String
updateUrl =
    Url.Builder.crossOrigin solrInstance
        [ "solr", solrCollection, "update" ]
        [ Url.Builder.string "commit" "true" ]


httpErrorToString : Http.Error -> String
httpErrorToString err =
    case err of
        Http.BadUrl url ->
            "Bad URL: " ++ url

        Http.Timeout ->
            "Request timed out."

        Http.NetworkError ->
            "Network error (is the Solr instance reachable, and is CORS allowed?)."

        Http.BadStatus code ->
            "Solr returned HTTP " ++ String.fromInt code ++ "."

        Http.BadBody message ->
            "Unexpected response: " ++ message



-- SUBSCRIPTIONS


subscriptions : Model -> Sub Msg
subscriptions _ =
    Sub.none



-- VIEW


view : Model -> Html Msg
view model =
    div [ style "font-family" "system-ui, sans-serif", style "max-width" "40rem", style "margin" "2rem auto", style "padding" "0 1rem" ]
        [ h1 [] [ text appTitle ]
        , viewInstance
        , viewForm model
        , viewFeedback model.flickerHidden model.feedback
        , viewConfirm model.confirm
        ]


viewInstance : Html Msg
viewInstance =
    p [ style "color" "#555" ]
        [ text "Solr instance: "
        , Html.code [] [ text (solrInstance ++ "/solr/" ++ solrCollection) ]
        ]


viewForm : Model -> Html Msg
viewForm model =
    div []
        [ label [ style "display" "block", style "font-weight" "bold", style "margin-bottom" "0.25rem" ]
            [ text "Store ID" ]

        -- Input, with the de-emphasised "Show Default" button to its right.
        , div [ style "display" "flex", style "gap" "0.5rem", style "align-items" "center" ]
            (input
                [ id "store-id"
                , value model.storeId
                , onInput StoreIdChanged

                -- Enter on the field triggers Check-Only.
                , onEnter CheckClicked
                , autofocus True
                , placeholder storeIdPrefix
                , style "flex" "1"
                , style "min-width" "0"
                , style "padding" "0.5rem"
                , style "box-sizing" "border-box"
                , style "font-family" "monospace"
                ]
                []
                :: (if useSeed then
                        [ button (onClick DefaultClicked :: tertiaryButtonStyle) [ text "Show Default" ] ]

                    else
                        []
                   )
            )
        , div [ style "margin-top" "0.75rem", style "display" "flex", style "gap" "0.5rem" ]
            -- Check-only is styled as the primary/default action (Enter).
            [ button
                (onClick CheckClicked
                    :: title "Default action — press Enter in the field"
                    :: primaryButtonStyle
                )
                [ text "Check only ⏎" ]
            , button (onClick DeleteClicked :: secondaryButtonStyle) [ text "Delete Document" ]
            ]
        ]


primaryButtonStyle : List (Attribute msg)
primaryButtonStyle =
    [ style "padding" "0.5rem 1rem"
    , style "background" "#0069d9"
    , style "color" "white"
    , style "border" "1px solid #0062cc"
    , style "border-radius" "4px"
    , style "font-weight" "bold"
    , style "cursor" "pointer"
    ]


secondaryButtonStyle : List (Attribute msg)
secondaryButtonStyle =
    [ style "padding" "0.5rem 1rem"
    , style "background" "#f1f1f1"
    , style "color" "#222"
    , style "border" "1px solid #bbb"
    , style "border-radius" "4px"
    , style "cursor" "pointer"
    ]


{-| A de-emphasised button: smaller and muted, for secondary/helper actions.
-}
tertiaryButtonStyle : List (Attribute msg)
tertiaryButtonStyle =
    [ style "padding" "0.3rem 0.7rem"
    , style "background" "transparent"
    , style "color" "#777"
    , style "border" "1px solid #ccc"
    , style "border-radius" "4px"
    , style "font-size" "0.6rem"
    , style "white-space" "nowrap"
    , style "cursor" "pointer"
    ]


{-| A prominent, destructive-action button (used for the delete confirmation).
-}
dangerButtonStyle : List (Attribute msg)
dangerButtonStyle =
    [ style "padding" "0.5rem 1rem"
    , style "background" "#c0392b"
    , style "color" "white"
    , style "border" "1px solid #a93226"
    , style "border-radius" "4px"
    , style "font-weight" "bold"
    , style "cursor" "pointer"
    ]


viewFeedback : Bool -> Feedback -> Html Msg
viewFeedback flickerHidden feedback =
    let
        message color content =
            p
                [ style "color" color
                , style "font-weight" "bold"
                , style "margin-top" "1rem"
                , style "opacity"
                    (if flickerHidden then
                        "0"

                     else
                        "1"
                    )
                , style "transition" "opacity 60ms"
                ]
                [ text content ]
    in
    case feedback of
        NoFeedback ->
            text ""

        Invalid msg ->
            message "#c0392b" msg

        Loading ->
            message "#555" "Checking…"

        Exists count ->
            message "#1e7e34" ("Document exists with " ++ String.fromInt count ++ " rows")

        Missing ->
            message "#b8860b" "Document does not exist"

        Deleting ->
            message "#555" "Deleting…"

        Deleted count ->
            message "#1e7e34" ("Deleted " ++ String.fromInt count ++ " rows")

        Failed reason ->
            message "#c0392b" ("Request failed: " ++ reason)


{-| The delete confirmation dialog: OK deletes, Cancel dismisses (leaving the
"Document exists with n rows" message in place).
-}
viewConfirm : Maybe Confirm -> Html Msg
viewConfirm confirm =
    case confirm of
        Nothing ->
            text ""

        Just c ->
            div
                [ style "position" "fixed"
                , style "inset" "0"
                , style "background" "rgba(0,0,0,0.4)"
                , style "display" "flex"
                , style "align-items" "center"
                , style "justify-content" "center"
                ]
                [ div
                    [ style "background" "white"
                    , style "padding" "1.5rem"
                    , style "border-radius" "8px"
                    , style "min-width" "20rem"
                    , style "max-width" "32rem"
                    , style "box-shadow" "0 4px 20px rgba(0,0,0,0.3)"
                    ]
                    [ p [ style "margin-top" "0", style "font-weight" "bold" ]
                        [ text ("Delete all " ++ String.fromInt c.count ++ " rows for this store ID?") ]
                    , p [ style "font-family" "monospace", style "color" "#555", style "word-break" "break-all" ]
                        [ text c.storeId ]
                    , div [ style "margin-top" "1rem", style "display" "flex", style "gap" "0.5rem", style "justify-content" "flex-end" ]
                        [ button (onClick CancelDelete :: secondaryButtonStyle) [ text "Cancel" ]
                        , button (onClick ConfirmDelete :: dangerButtonStyle) [ text "OK" ]
                        ]
                    ]
                ]


{-| Fire `msg` when Enter is pressed in an element.
-}
onEnter : msg -> Attribute msg
onEnter msg =
    Html.Events.on "keydown"
        (Decode.field "key" Decode.string
            |> Decode.andThen
                (\key ->
                    if key == "Enter" then
                        Decode.succeed msg

                    else
                        Decode.fail "not Enter"
                )
        )
