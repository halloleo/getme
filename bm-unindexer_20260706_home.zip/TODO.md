# TODO

### 2026-07-02

- [x] Minimal functionality: accept a store id and show rows.
- [x] Add delete function.
