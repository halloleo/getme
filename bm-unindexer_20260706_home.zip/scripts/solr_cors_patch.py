#!/usr/bin/env python3
"""Idempotently add Jetty's CrossOriginFilter to a Solr webapp web.xml.

Usage: solr_cors_patch.py <path-to-web.xml>

Inserts a <filter>/<filter-mapping> pair for org.eclipse.jetty.servlets.
CrossOriginFilter before the existing ones (so it runs first). Does nothing
if the file already mentions "cross-origin".
"""
import sys

FILTER = """  <filter>
    <filter-name>cross-origin</filter-name>
    <filter-class>org.eclipse.jetty.servlets.CrossOriginFilter</filter-class>
    <init-param><param-name>allowedOrigins</param-name><param-value>*</param-value></init-param>
    <init-param><param-name>allowedMethods</param-name><param-value>GET,POST,OPTIONS,DELETE,PUT,HEAD</param-value></init-param>
    <init-param><param-name>allowedHeaders</param-name><param-value>origin,content-type,accept,authorization</param-value></init-param>
  </filter>
"""

MAPPING = """  <filter-mapping>
    <filter-name>cross-origin</filter-name>
    <url-pattern>/*</url-pattern>
  </filter-mapping>
"""


def patch(xml: str) -> str:
    if "cross-origin" in xml:
        return xml
    i = xml.index("<filter>")
    xml = xml[:i] + FILTER + xml[i:]
    j = xml.index("<filter-mapping>")
    xml = xml[:j] + MAPPING + xml[j:]
    return xml


def main() -> int:
    path = sys.argv[1]
    original = open(path, encoding="utf-8").read()
    patched = patch(original)
    if patched == original:
        print("  already patched — skipping")
        return 0
    open(path, "w", encoding="utf-8").write(patched)
    print("  inserted CrossOriginFilter")
    return 0


if __name__ == "__main__":
    sys.exit(main())
