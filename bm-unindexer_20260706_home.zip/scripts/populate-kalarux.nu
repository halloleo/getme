#!/usr/bin/env nu

# Populate the `kalarux` test collection from `techproducts`.
#
# Prerequisite: the `kalarux` core must already exist (created on the Solr host
# with `solr create -c kalarux -d .../sample_techproducts_configs`). Everything
# below runs purely over the Solr HTTP API.
#
# We talk to Solr through `curl` rather than Nushell's `http` builtin: the
# builtin can't reach `purelyfunctional.local` (it trips over the host's
# link-local IPv6 address), while curl resolves and connects fine.
#
# Each resulting document:
#   * carries an `identifier` field (a copy of the doc's `id`; `id` stays the
#     uniqueKey, so no configset change is needed),
#   * carries a `store` field, distributed over 32 docs as:
#       -  8 random docs -> fusion:/store/11111111-1111-1111-1111-111111111111
#       -  8 random docs -> fusion:/store/22222222-2222-2222-2222-222222222222
#       - 16 remaining   -> fusion:/store/f439375d-98d1-4940-bef2-11a727ed8376

const base = "http://purelyfunctional.local:8983/solr"
const src  = "techproducts"
const dst  = "kalarux"

const store_a = "fusion:/store/11111111-1111-1111-1111-111111111111"
const store_b = "fusion:/store/22222222-2222-2222-2222-222222222222"
const store_c = "fusion:/store/f439375d-98d1-4940-bef2-11a727ed8376"

# GET a Solr endpoint and parse the JSON body.
def solr-get [url: string] {
    ^curl -sf $url | from json
}

# POST a JSON body to a Solr endpoint and parse the JSON response.
def solr-post [url: string, body: any] {
    $body | to json | ^curl -s -H "Content-Type: application/json" --data-binary @- $url | from json
}

def main [] {
    # --- 1. Ensure the schema fits: `store` as string, plus an `identifier` field ---
    let fields = (solr-get $"($base)/($dst)/schema/fields").fields
    let names = ($fields | get name)
    let store_type = ($fields | where name == "store" | get -o 0.type)

    mut ops = {}
    if $store_type != "string" {
        # techproducts ships `store` as a location (lat/lon) field; we need a plain string.
        $ops = ($ops | insert "replace-field" {
            name: "store", type: "string", indexed: true, stored: true, multiValued: false
        })
    }
    if not ("identifier" in $names) {
        $ops = ($ops | insert "add-field" {
            name: "identifier", type: "string", indexed: true, stored: true, multiValued: false
        })
    }
    if ($ops | is-not-empty) {
        print $"Applying schema changes: ($ops | columns | str join ', ')"
        let r = (solr-post $"($base)/($dst)/schema" $ops)
        if $r.responseHeader.status != 0 {
            error make { msg: $"Schema update failed: ($r | to json)" }
        }
    } else {
        print "Schema already up to date."
    }

    # --- 2. Fetch the 32 source documents ---
    let docs = (solr-get $"($base)/($src)/select?q=*:*&rows=1000").response.docs
    print $"Fetched (($docs | length)) documents from '($src)'."

    # --- 3. Transform: drop internals + original `store`, add `identifier` and a
    #        randomly-distributed `store`. ---
    let prepared = ($docs | shuffle | enumerate | each { |it|
        let store_val = if $it.index < 8 { $store_a
        } else if $it.index < 16 { $store_b
        } else { $store_c }

        mut d = $it.item
        for col in ["_version_" "store"] {
            if $col in ($d | columns) { $d = ($d | reject $col) }
        }
        $d | insert identifier $d.id | insert store $store_val
    })

    # --- 4. Index into kalarux and commit ---
    let r = (solr-post $"($base)/($dst)/update?commit=true" $prepared)
    if $r.responseHeader.status != 0 {
        error make { msg: $"Indexing failed: ($r | to json)" }
    }

    # --- 5. Report ---
    let total = (solr-get $"($base)/($dst)/select?q=*:*&rows=0").response.numFound
    let by_store = ($prepared | group-by store | items { |k, v| { store: $k, count: ($v | length) } })
    print $"Indexed into '($dst)'. Total docs now: ($total)."
    print ($by_store | table)
}
