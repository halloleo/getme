;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purescript-mode" "20260717.1433"
  "A PureScript editing mode."
  '((emacs "25.1"))
  :url "https://github.com/purescript-emacs/purescript-mode"
  :commit "7ad5eff9bd59632d49a44f5935c65f1069e17fed"
  :revdesc "7ad5eff9bd59"
  :keywords '("faces" "files" "purescript")
  :authors '(("1997-1998 Graeme E Moss and" . "gem@cs.york.ac.uk")
             ("Tommy Thorn" . "thorn@irisa.fr")
             ("2003 Dave Love" . "fx@gnu.org")
             ("2014 Tim Dysinger" . "tim@dysinger.net"))
  :maintainers '(("1997-1998 Graeme E Moss and" . "gem@cs.york.ac.uk")
                 ("Tommy Thorn" . "thorn@irisa.fr")
                 ("2003 Dave Love" . "fx@gnu.org")
                 ("2014 Tim Dysinger" . "tim@dysinger.net")))
