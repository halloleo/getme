;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repl-toggle" "20220920.752"
  "Switch to/from repl buffer for current major-mode."
  '((fullframe "0.0.5"))
  :url "https://git.sr.ht/~tomterl/repl-toggle"
  :commit "e05996b4a2b988f93ccce67f933cfad00064360f"
  :revdesc "e05996b4a2b9"
  :keywords '("repl" "buffers" "toggle")
  :authors '(("Tom Regner" . "tom@goochesa.de"))
  :maintainers '(("Tom Regner" . "tom@goochesa.de")))
