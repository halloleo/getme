;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-compile" "20251229.2123"
  "An interface to `compile'."
  ()
  :url "https://github.com/zenitani/elisp"
  :commit "9f5e8387b0d703a11bff6133d2c5b556d8be0a17"
  :revdesc "9f5e8387b0d7"
  :keywords '("tools" "unix")
  :authors '(("Seiji Zenitani" . "zenitani@gmail.com"))
  :maintainers '(("Seiji Zenitani" . "zenitani@gmail.com")))
