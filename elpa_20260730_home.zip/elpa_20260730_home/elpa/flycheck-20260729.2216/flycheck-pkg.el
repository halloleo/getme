;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260729.2216"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "b3243a833a9c9123347c8ad52711b5bd281be795"
  :revdesc "b3243a833a9c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
