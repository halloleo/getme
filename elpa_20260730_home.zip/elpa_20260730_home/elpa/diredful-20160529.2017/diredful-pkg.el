;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredful" "20160529.2017"
  "Colorful file names in dired buffers."
  ()
  :url "https://github.com/thamer/diredful"
  :commit "b17b3087e0084a5571a9ac4d47ccfc36d96b109e"
  :revdesc "b17b3087e008"
  :keywords '("dired" "colors" "extension" "widget")
  :authors '(("Thamer Mahmoud" . "thamer.mahmoud@gmail.com"))
  :maintainers '(("Thamer Mahmoud" . "thamer.mahmoud@gmail.com")))
