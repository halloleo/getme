"""
Test muddle
"""
import sys

import pytest
import glob
import muddle

class Test_funcs():

    def test_muddle_me(self, tmp_path):
        in_fname = 'data/twinimal_orig.txt'
        actual_fname = tmp_path / 'actual.txt'
        expected_fname = 'data/twinimal_converted.txt'
        with open(in_fname, 'rb') as input:
            with open(actual_fname, 'w') as output:

                muddle.muddle_me(input, output)

        with open(actual_fname) as actual_f:
            actual_lines = actual_f.readlines()
        with open(expected_fname) as expected_f:
            expected_lines = expected_f.readlines()
        assert actual_lines == expected_lines

    def test_demuddle_me(self, tmp_path):
        in_fname = 'data/twinimal_converted.txt'
        actual_fname = tmp_path / 'actual.txt'
        expected_fname = 'data/twinimal_orig.txt'
        with open(in_fname, 'r') as input:
            with open(actual_fname, 'wb') as output:

                muddle.demuddle_me(input, output)

        with open(actual_fname) as actual_f:
            actual_lines = actual_f.readlines()
        with open(expected_fname) as expected_f:
            expected_lines = expected_f.readlines()
        assert actual_lines == expected_lines


class Test_roundtrip():

    roundtrip_files = glob.glob('./data/*_roundtrip.*')
    @pytest.mark.parametrize('fname', roundtrip_files)
    def test_roundtrip(self, tmp_path, fname):
        # Muddle (Convert)
        converted_fname = tmp_path / 'converted.txt'
        with open(fname, 'rb') as input:
            with open(converted_fname, 'w') as output:
                muddle.muddle_me(input, output)

        # Demuddle (restore)
        restored_fname = tmp_path / 'restored.txt'
        with open(converted_fname, 'r') as input:
            with open(restored_fname, 'wb') as output:
                muddle.demuddle_me(input, output)

        with open(fname) as orig_f:
            orig_lines = orig_f.readlines()
        with open(restored_fname) as restored_f:
            restored_lines = restored_f.readlines()
        assert restored_lines == orig_lines


