#!/usr/bin/env python3
"""
Muddle some text
"""

from muddle_funcs import muddle_me, demuddle_me

import click

DEBUG = False

@click.group()
@click.option('-d', '--debug', is_flag=True, help='Issue char-based debug info.')
def cli(debug):
    """
    Muddle and demuddle files.
    """
    global DEBUG
    DEBUG = debug

@cli.command()
@click.argument('input', type=click.File('rb'))
@click.argument('output', type=click.File('w'))
def convert(input, output, muddler=None):
    """
    Muddle file INPUT and write the result to OUTPUT.

    INPUT and OUTPUT put can be '-' for stdin and stdout.
    """
    muddle_me(input, output, muddler, debug=DEBUG)


@cli.command()
@click.argument('input', type=click.File('r'))
@click.argument('output', type=click.File('wb'))
@click.option('-f', '--dont-fail', is_flag=True, default=False,
              help="Do not fail when a character cannot be restored.")
def restore(input, output, dont_fail=False, muddler=None):
    """
    Demuddle the muddled file INPUT and write the result to OUTPUT.

    INPUT and OUTPUT put can be '-' for stdin and stdout.
    """
    demuddle_me(input, output, muddler, dont_fail, debug=DEBUG)

if __name__ == '__main__':
    cli()