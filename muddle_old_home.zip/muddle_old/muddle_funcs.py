"""
Functions for muddling some text
"""
import io
import sys
import shutil

# Number of possible "characters" in a byte
MAXBYTE = 255

# The separator used on a line in the muddled text
MUDDLED_SEP = ' '

# Muddler text V1: NumPy license
M1_MUDDLER = """
Copyright (c) 2005-2019, NumPy Developers.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
       copyright notice, this list of conditions and the following
       disclaimer in the documentation and/or other materials provided
       with the distribution.

    * Neither the name of the NumPy Developers nor the names of any
       contributors may be used to endorse or promote products derived
       from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



The NumPy repository and source distributions bundle several libraries that are
compatibly licensed.  We list these here.

Name: Numpydoc
Files: doc/sphinxext/numpydoc/*
License: 2-clause BSD
  For details, see doc/sphinxext/LICENSE.txt

Name: scipy-sphinx-theme
Files: doc/scipy-sphinx-theme/*
License: 3-clause BSD, PSF and Apache 2.0
  For details, see doc/scipy-sphinx-theme/LICENSE.txt

Name: lapack-lite
Files: numpy/linalg/lapack_lite/*
License: 3-clause BSD
  For details, see numpy/linalg/lapack_lite/LICENSE.txt

Name: tempita
Files: tools/npy_tempita/*
License: BSD derived
  For details, see tools/npy_tempita/license.txt

Name: dragon4
Files: numpy/core/src/multiarray/dragon4.c
License: One of a kind
  For license text, see numpy/core/src/multiarray/dragon4.c

----

This binary distribution of NumPy also bundles the following software:


Name: OpenBLAS
Files: .libs/libopenb*.so
Description: bundled as a dynamically linked library
Availability: https://github.com/xianyi/OpenBLAS/
License: 3-clause BSD
  Copyright (c) 2011-2014, The OpenBLAS Project
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:

     1. Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in
        the documentation and/or other materials provided with the
        distribution.
     3. Neither the name of the OpenBLAS project nor the names of
        its contributors may be used to endorse or promote products
        derived from this software without specific prior written
        permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Name: LAPACK
Files: .libs/libopenb*.so
Description: bundled in OpenBLAS
Availability: https://github.com/xianyi/OpenBLAS/
License 3-clause BSD
  Copyright (c) 1992-2013 The University of Tennessee and The University
                          of Tennessee Research Foundation.  All rights
                          reserved.
  Copyright (c) 2000-2013 The University of California Berkeley. All
                          rights reserved.
  Copyright (c) 2006-2013 The University of Colorado Denver.  All rights
                          reserved.

  $COPYRIGHT$

  Additional copyrights may follow

  $HEADER$

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:

  - Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  - Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer listed
    in this license in the documentation and/or other materials
    provided with the distribution.

  - Neither the name of the copyright holders nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

  The copyright holders provide no reassurances that the source code
  provided does not infringe any patent, copyright, or any other
  intellectual property rights of third parties.  The copyright holders
  disclaim any liability to any recipient for claims brought against
  recipient by any third party for infringement of that parties
  intellectual property rights.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Name: GCC runtime library
Files: .libs/libgfortran*.so
Description: dynamically linked to files compiled with gcc
Availability: https://gcc.gnu.org/viewcvs/gcc/
License: GPLv3 + runtime exception
  Copyright (C) 2002-2017 Free Software Foundation, Inc.

  Libgfortran is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.

  Libgfortran is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  Under Section 7 of GPL version 3, you are granted additional
  permissions described in the GCC Runtime Library Exception, version
  3.1, as published by the Free Software Foundation.

  You should have received a copy of the GNU General Public License and
  a copy of the GCC Runtime Library Exception along with this program;
  see the files COPYING3 and COPYING.RUNTIME respectively.  If not, see
  <http://www.gnu.org/licenses/>.
"""

# Muddler text V1: Machine learning intro (2 section from
# https://www.digitalocean.com/community/tutorials/an-introduction-to-machine-learning)
M2_MUDDLER = """
In machine learning, tasks are generally classified into broad
categories. These categories are based on how learning is received or how
feedback on the learning is given to the system developed.

Two of the most widely adopted machine learning methods are supervised learning
which trains algorithms based on example input and output data that is labeled
by humans, and unsupervised learning which provides the algorithm with no
labeled data in order to allow it to find structure within its input
data. Let’s explore these methods in more detail.  Supervised Learning

In supervised learning, the computer is provided with example inputs that are
labeled with their desired outputs. The purpose of this method is for the
algorithm to be able to “learn” by comparing its actual output with the
“taught” outputs to find errors, and modify the model accordingly. Supervised
learning therefore uses patterns to predict label values on additional
unlabeled data.

For example, with supervised learning, an algorithm may be fed data with images
of sharks labeled as fish and images of oceans labeled as water. By being
trained on this data, the supervised learning algorithm should be able to later
identify unlabeled shark images as fish and unlabeled ocean images as water.

A common use case of supervised learning is to use historical data to predict
statistically likely future events. It may use historical stock market
information to anticipate upcoming fluctuations, or be employed to filter out
spam emails. In supervised learning, tagged photos of dogs can be used as input
data to classify untagged photos of dogs.  Unsupervised Learning

In unsupervised learning, data is unlabeled, so the learning algorithm is left
to find commonalities among its input data. As unlabeled data are more abundant
than labeled data, machine learning methods that facilitate unsupervised
learning are particularly valuable.

The goal of unsupervised learning may be as straightforward as discovering
hidden patterns within a dataset, but it may also have a goal of feature
learning, which allows the computational machine to automatically discover the
representations that are needed to classify raw data.

Unsupervised learning is commonly used for transactional data. You may have a
large dataset of customers and their purchases, but as a human you will likely
not be able to make sense of what similar attributes can be drawn from customer
profiles and their types of purchases. With this data fed into an unsupervised
learning algorithm, it may be determined that women of a certain age range who
buy unscented soaps are likely to be pregnant, and therefore a marketing
campaign related to pregnancy and baby products can be targeted to this
audience in order to increase their number of purchases.

Without being told a “correct” answer, unsupervised learning methods can look
at complex data that is more expansive and seemingly unrelated in order to
organize it in potentially meaningful ways. Unsupervised learning is often used
for anomaly detection including for fraudulent credit card purchases, and
recommender systems that recommend what products to buy next. In unsupervised
learning, untagged photos of dogs can be used as input data for the algorithm
to find likenesses and classify dog photos together.  Approaches

As a field, machine learning is closely related to computational statistics, so
having a background knowledge in statistics is useful for understanding and
leveraging machine learning algorithms.

For those who may not have studied statistics, it can be helpful to first
define correlation and regression, as they are commonly used techniques for
investigating the relationship among quantitative variables. Correlation is a
measure of association between two variables that are not designated as either
dependent or independent. Regression at a basic level is used to examine the
relationship between one dependent and one independent variable. Because
regression statistics can be used to anticipate the dependent variable when the
independent variable is known, regression enables prediction capabilities.

Approaches to machine learning are continuously being developed. For our
purposes, we’ll go through a few of the popular approaches that are being used
in machine learning at the time of writing.
"""

STANDARD_MUDDLER = M2_MUDDLER


def make_muddle_list(muddler_fname):
    """
    Generate a list of words from a muddler text.

    Args:
        muddler_fname: text file to create the muddle list from

    Returns:
        Muddle list of words. The words in the list will be unique.

    Raises:
        If the length of the list is less than 256 an execption is raised.
    """

    try:
        if muddler_fname:
            mf = open(muddler_fname)
        else:
            mf = io.StringIO(STANDARD_MUDDLER)

        ml = []
        seen = {}
        for line in mf.readlines():
            for word in line.split():
                if word in seen:
                    continue
                seen[word] = 1
                ml.append(word)
    finally:
        if mf:
            mf.close()

    if len(ml) <= MAXBYTE:
        raise ValueError(f"Muddler text contains only {len(ml)} unique words."
                         f"This is less than the needed {MAXBYTE+1} words.")
    return ml


def muddle_me_v1(input, output, muddler_fname=None, debug=None):
    """
    Muddle text with a fix-positional char-to-word mapping
    """
    ml = make_muddle_list(muddler_fname)
    for line in input.readlines():
        for c in line:
            if c > MAXBYTE:
                raise ValueError(f"Byte value larger than {MAXBYTE}")
            print(ml[c], end=MUDDLED_SEP, file=output)
        print(file=output)


def demuddle_me_v1(input, output, muddler_fname=None, debug=None):
    """
    Demuddle text with a fix-positional char-to-word mapping
    """
    ml = make_muddle_list(muddler_fname)
    for line in input.readlines():
        line = line.rstrip(' \n')

        for word in line.split(sep=MUDDLED_SEP):
            c = ml.index(word) # For correctly muddled text this
                               # should never raise a ValueError
            output.write(bytes([c]))


def muddle_me_v2(input, output, muddler_fname=None, debug=None):
    """
    Muddle text with a position-increasing char-to-word mapping
    """
    ml = make_muddle_list(muddler_fname)
    i = 0
    for line in input.readlines():
        #line = line.rstrip('\n')
        for c in line:
            i += 1
            idx = (c+i) % MAXBYTE
            print(ml[idx], end=MUDDLED_SEP, file=output)
            if debug:
                print(chr(c), idx, file=sys.stderr)
        print(file=output)


def demuddle_me_v2(input, output, muddler_fname=None, dont_fail=True, debug=None):
    """
    Demuddle text with a position-increasing char-to-word mapping
    """
    ml = make_muddle_list(muddler_fname)
    i = 0
    for line in input.readlines():
        line = line.rstrip(' \n')
        for word in line.split(sep=MUDDLED_SEP):
            i += 1
            try:
                c = ml.index(word) # Should not fail for correct muddled text
                idx = (c-i) % MAXBYTE
                if debug:
                    print(chr(idx), idx, file=sys.stderr)
                output.write(bytes([idx]))
            except ValueError as e:
                if dont_fail:
                    output.write("_".encode())
                else:
                    raise

muddle_me = muddle_me_v2
demuddle_me = demuddle_me_v2